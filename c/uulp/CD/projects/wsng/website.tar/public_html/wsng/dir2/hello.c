#include	<stdio.h>

main()
{
	printf("Content-type: text/html\r\n");
	printf("\r\n");

	printf("<html><body bgcolor=blue><b>hello, world\n");
}
