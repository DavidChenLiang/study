#define	VARLEN	25
#define	YES	1
#define	NO	0
#define	FALSE	NO
#define	TRUE	YES

#define	MAXARG		20
#define	MAXCMDLEN	512
#define	DFL_PROMPT	"> "

#define	ISBLANK(x)	((x)==' '|| (x)=='\t')
